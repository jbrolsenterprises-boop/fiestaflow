const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
const titles={overview:'Daily overview',pos:'Branch POS',sales:'Sales history',dispatch:'Dispatch & routes',inventory:'Inventory & custody',accounts:'Franchisee accounts',approvals:'Approvals & exceptions',vehicles:'Vehicles & crew',reports:'Reports'};
const users={president:{name:'President',role:'Executive Access',initials:'P',pages:['overview','pos','sales','dispatch','inventory','accounts','approvals','vehicles','reports']},central:{name:'Maria P.',role:'Central Operations',initials:'MP',scope:'warehouse-pos',pages:['overview','pos','sales','dispatch','inventory','accounts','approvals','vehicles','reports']},cashier:{name:'Liza C.',role:'BGC Branch Cashier',initials:'LC',scope:'branch',pages:['overview','pos','sales','inventory','reports']},warehouse:{name:'Paolo R.',role:'Warehouse Receiver',initials:'PR',scope:'warehouse',pages:['dispatch','inventory','vehicles']},driver:{name:'Ramon D.',role:'Driver',initials:'RD',pages:['driver']},sales:{name:'Ana L.',role:'Sales Personnel',initials:'AL',scope:'accounts',pages:['accounts']}};
let currentUser=null;
function toast(message){const t=$('#toast');t.textContent=message;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function go(page){if(currentUser&&!currentUser.pages.includes(page)){toast('This role does not have access to that area.');return}$$('.page').forEach(p=>p.classList.remove('active'));$('#'+page).classList.add('active');$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===page));$('#head').textContent=titles[page]||'Driver route';$('.side').classList.remove('open');window.scrollTo(0,0)}
function applyPermissions(){const isDriver=currentUser.pages.length===1&&currentUser.pages[0]==='driver',branch=currentUser.scope==='branch',accountsOnly=currentUser.scope==='accounts',warehousePos=currentUser.scope==='warehouse-pos';document.body.classList.toggle('branch-session',branch);$$('.nav').forEach(n=>n.hidden=!currentUser.pages.includes(n.dataset.page));$('.side').style.display=isDriver?'none':'flex';$('header').style.display=isDriver?'none':'flex';$('#profileName').textContent=currentUser.name;$('#profileRole').textContent=currentUser.role;$('#profileButton').querySelector('span').textContent=currentUser.initials;$('#pos .title small').textContent=warehousePos?'MAIN WAREHOUSE · PICKUP COUNTER 01':'BGC BRANCH · REGISTER 01';
 const overview=$('#overview');overview.querySelector('.title small').textContent=branch?'BGC BRANCH · YOUR ASSIGNED LOCATION':'FRIDAY, 22 AUGUST 2026';overview.querySelector('.title h1').textContent=branch?'BGC Branch at a glance':'Operations at a glance';$$('#overview .grid').forEach(grid=>grid.hidden=branch);const metricText=branch?[['BRANCH SALES TODAY','₱17,040','3 completed transactions'],['BRANCH COLLECTIONS','₱17,040','All completed sales collected'],['BRANCH DELIVERY','1','/ 1 vehicle active'],['BRANCH STOCK ALERT','18','filled crates · target 45']]:[['SALES TODAY','₱128,640','34 completed transactions'],['COLLECTIONS TO RECONCILE','₱42,900','2 active routes · cash & cheque'],['ACTIVE ROUTES','2','/ 3 vehicles'],['STOCK ATTENTION','3','Locations below 3× daily buffer']];$$('#overview .metrics article').forEach((card,i)=>{card.querySelector('small').textContent=metricText[i][0];card.querySelector('b').childNodes[0].nodeValue=metricText[i][1];card.querySelector('span').textContent=metricText[i][2];card.hidden=i===1});const vehicleMini=$('#overview .metrics article:nth-child(3) b small');if(vehicleMini)vehicleMini.textContent=branch?'/ 1 vehicle':'/ 3 vehicles';
 $('#inventory .title small').textContent=branch?'BGC BRANCH · ASSIGNED STOCK':'ALL LOCATIONS';$('#inventory .title h1').textContent=branch?'BGC Branch inventory & custody':'Inventory & custody';$('#inventory .notice span').textContent=branch?'BGC Branch is 27 crates below its 3× daily sales target.':'Target = 3 × rolling daily sales volume. BGC is 27 crates below target.';$$('#inventory tbody tr').forEach(row=>row.hidden=branch&&!row.textContent.includes('BGC Branch'));$('#inventory .grid>aside').hidden=branch;
 $('#reports h1').textContent=branch?'BGC Branch reports':'Reports';$('#reports p').textContent=branch?'Branch sales, stock counts, cashier transactions, and payment handover reports will be available here.':'Daily operations, route reconciliation, stock custody, payments, and commissions are wired into the first-version data model.';
 $('#accounts .title small').textContent=accountsOnly?'MY ASSIGNED ACCOUNTS':'CUSTOMER RELATIONSHIPS';$('#accounts .title h1').textContent=accountsOnly?'My account overview':'Franchisee accounts';$('#accounts .title .primary').hidden=accountsOnly;$('#accounts .account-cards').hidden=accountsOnly;$$('#accounts tbody tr').forEach(row=>row.hidden=accountsOnly&&!row.textContent.includes('A. Lim'));renderSales();}
$$('.nav').forEach(n=>n.addEventListener('click',()=>go(n.dataset.page)));$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));$('#menu').addEventListener('click',()=>$('.side').classList.toggle('open'));
$('#driverMode').addEventListener('click',()=>{go('driver');$('.side').style.display='none';$('header').style.display='none'});$('#exitDriver').addEventListener('click',()=>{if(currentUser.pages.includes('overview')){$('.side').style.display='flex';$('header').style.display='flex';go('overview')}else $('#loginScreen').classList.remove('hidden')});
$('#profileButton').addEventListener('click',()=>{$('#loginRole').value=Object.entries(users).find(([,user])=>user===currentUser)?.[0]||'central';$('#loginScreen').classList.remove('hidden')});
$('#loginForm').addEventListener('submit',event=>{event.preventDefault();currentUser=users[$('#loginRole'].value];applyPermissions();$('#loginScreen').classList.add('hidden');go(currentUser.pages[0]);toast(`Signed in as ${currentUser.name}.`)});
const salesTransactions=[
 {date:'2026-08-22',time:'8:42 AM',branch:'BGC Branch',customer:'Walk-in customer',type:'New cylinder sale',payment:'Cash',total:1600,exchange:false,newCylinders:4},
 {date:'2026-08-22',time:'10:18 AM',branch:'BGC Branch',customer:'Walk-in customer',type:'Cylinder exchange',payment:'Cash',total:7640,exchange:true,newCylinders:0},
 {date:'2026-08-22',time:'1:06 PM',branch:'BGC Branch',customer:'Delos Reyes Trading',type:'Franchisee exchange',payment:'GCash',total:7800,exchange:true,newCylinders:0},
 {date:'2026-08-22',time:'9:15 AM',branch:'Quezon City Branch',customer:'Quezon Gas Depot',type:'Crate exchange',payment:'Cash',total:4752,exchange:true,newCylinders:0},
 {date:'2026-08-22',time:'11:32 AM',branch:'Main warehouse',customer:'Northway Retail Hub',type:'Opening sale',payment:'Bank transfer',total:15000,exchange:false,newCylinders:24},
 {date:'2026-08-15',time:'9:04 AM',branch:'BGC Branch',customer:'Walk-in customer',type:'Cylinder exchange',payment:'Cash',total:4200,exchange:true,newCylinders:0},
 {date:'2026-08-15',time:'10:37 AM',branch:'BGC Branch',customer:'Delos Reyes Trading',type:'Franchisee exchange',payment:'GCash',total:6240,exchange:true,newCylinders:0},
 {date:'2026-08-15',time:'1:22 PM',branch:'Quezon City Branch',customer:'J & M General Merchandise',type:'Crate exchange',payment:'Cheque',total:9504,exchange:true,newCylinders:0},
 {date:'2026-08-15',time:'3:46 PM',branch:'Main warehouse',customer:'Marites Store',type:'New cylinder sale',payment:'Cash',total:3200,exchange:false,newCylinders:8}
];
function peso(value){return '₱'+value.toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2})}
function salesDateLabel(date){return new Intl.DateTimeFormat('en-PH',{month:'long',day:'numeric',year:'numeric'}).format(new Date(`${date}T12:00:00`))}
function renderSales(){if(!currentUser)return;const branchLocked=currentUser.scope==='branch',branchControl=$('#salesBranch'),date=$('#salesDate').value,payment=$('#salesPayment').value;branchControl.value=branchLocked?'BGC Branch':branchControl.value;branchControl.disabled=branchLocked;const filtered=salesTransactions.filter(s=>s.date===date&&(branchLocked||branchControl.value==='all'||s.branch===branchControl.value)&&(payment==='all'||s.payment===payment));const total=filtered.reduce((sum,s)=>sum+s.total,0),exchanges=filtered.filter(s=>s.exchange).length,newCylinders=filtered.reduce((sum,s)=>sum+s.newCylinders,0);$('#salesTotal').textContent=peso(total);$('#salesCollected').textContent=peso(total);$('#salesCount').textContent=`${filtered.length} transaction${filtered.length===1?'':'s'}`;$('#salesExchanges').textContent=exchanges;$('#salesNewCylinders').textContent=newCylinders;$('#salesTableTitle').textContent=`Sales for ${salesDateLabel(date)}`;$('#salesRows').innerHTML=filtered.length?filtered.map(s=>`<tr tabindex="0"><td>${s.time}</td><td><b>${s.branch}</b></td><td>${s.customer}</td><td>${s.type}</td><td>${s.payment}</td><td><b>${peso(s.total)}</b></td><td><em class="chip">COMPLETED</em></td></tr>`).join(''):'<tr><td colspan="7">No sales match these filters.</td></tr>';$$('#salesRows tr[tabindex]').forEach((row,index)=>row.addEventListener('click',()=>toast(`Transaction record opened: ${filtered[index].type} · ${peso(filtered[index].total)}.`))}
$('#applySalesFilter').addEventListener('click',renderSales);$('#salesDate').addEventListener('change',renderSales);$('#salesBranch').addEventListener('change',renderSales);$('#salesPayment').addEventListener('change',renderSales);
const metricPanel=document.createElement('section');metricPanel.className='metric-detail panel';metricPanel.hidden=true;$('#overview .metrics').insertAdjacentElement('afterend',metricPanel);
function showMetricDetail(index){const branch=currentUser?.scope==='branch';const centralDetails=[
 ['Sales today','34 completed transactions · includes payment collection breakdown',[['Branch POS','₱72,540','19 transactions'],['Truck sales','₱41,100','10 transactions'],['Warehouse pickup','₱15,000','5 transactions'],['Cash received','₱84,120','Reconcile by cashier/driver'],['Cheque received','₱12,480','Deposit pending'],['Digital payments','₱32,040','GCash and bank transfer']]],
 ['Collections to reconcile','Route and payment breakdown',[['Cash on routes','₱24,420','2 driver handovers'],['Cheque','₱12,480','1 deposit pending'],['Digital payments','₱6,000','GCash and bank transfer']]],
 ['Active routes','Vehicle status',[['WH-01','3 of 6 stops','Ramon D. · Ana L.'],['BR-BGC-01','1 of 5 stops','Joel R. · Mark C.'],['BR-QC-01','Idle','Capacity setup pending']]],
 ['Stock attention','Locations below buffer',[['BGC Branch','18 / 45 crates','27 crates below target'],['Main warehouse','420 / 504 crates','84 crates below target'],['QC Branch','71 / 96 crates','25 crates below target']]]
 ];const branchDetails=[
 ['BGC Branch sales today','3 completed transactions · includes payment collection breakdown',[['Walk-in cylinder sales','₱9,240','Includes 4 new cylinders'],['Franchisee exchange','₱7,800','Content-only exchange'],['New cylinders','4 units','Included in walk-in sales'],['Cash received','₱9,240','Walk-in cylinder sales'],['GCash received','₱7,800','Franchisee exchange'],['Bank transfer','₱0.00','No bank-transfer sale today']]],
 ['BGC Branch collections','Payment breakdown — all completed sales are paid immediately',[['Cash','₱9,240','Walk-in cylinder sales'],['GCash','₱7,800','Franchisee exchange'],['Bank transfer','₱1,600','New cylinder sale']]],
 ['BGC Branch delivery','Assigned vehicle status',[['BR-BGC-01','1 of 5 stops','Joel R. · Mark C.'],['Current truck load','36 filled crates','12 empty crates returned'],['Collections','₱4,280','To reconcile on return']]],
 ['BGC Branch stock','Stock position',[['Filled crates','18','Target: 45 crates'],['Empty crates','32','Available for exchange'],['Replenishment need','27 crates','Request central transfer']]]
 ];const detail=(branch?branchDetails:centralDetails)[index];if(!detail)return;metricPanel.innerHTML=`<div class="metric-detail-head"><div><small>DETAIL BREAKDOWN</small><h2>${detail[0]}</h2><p>${detail[1]}</p></div><button class="outline" type="button" id="closeMetricDetail">Close ×</button></div><div class="metric-detail-grid">${detail[2].map(item=>`<article><small>${item[0]}</small><b>${item[1]}</b><span>${item[2]}</span></article>`).join('')}</div>`;metricPanel.hidden=false;$$('#overview .metrics article').forEach((card,i)=>card.classList.toggle('selected',i===index));$('#closeMetricDetail').addEventListener('click',()=>{metricPanel.hidden=true;$$('#overview .metrics article').forEach(card=>card.classList.remove('selected'))});}
$$('#overview .metrics article').forEach((card,index)=>{card.tabIndex=0;card.setAttribute('role','button');card.addEventListener('click',event=>{if(event.target.closest('button'))return;showMetricDetail(index)});card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();showMetricDetail(index)}})});
$$('.approve').forEach(b=>b.addEventListener('click',()=>{b.textContent='Approved ✓';b.disabled=true;b.closest('.panel').style.opacity='.55';toast('Approval recorded in the audit log.')}));$('#newRoute').addEventListener('click',()=>toast('Route creation is ready for dispatch setup.'));

// --- SUPABASE-CONNECTED POS CATALOG & STATE ---

// Fallback product catalog if tables are loading or offline
let productCatalog = {
    refill: { name: 'Refill', unit: 'Cylinder', price: 2376, returnable: true, discountable: true, description: 'Content only when the empty cylinder is returned.' },
    cylinder: { name: 'New cylinder', unit: 'Cylinder', price: 1850, returnable: false, discountable: true, description: 'Cylinder/container plus gas content.' },
    crate: { name: 'Crate', unit: 'Crate', price: 0, returnable: true, discountable: false, description: 'Custody item — selling price to be configured.' }
};

let cart=[];
let franchiseeAccounts=[{id:'delos',name:'Delos Reyes Trading',package:'Gold package'},{id:'northway',name:'Northway Retail Hub',package:'Starter package'}];

// Fetch active products from Supabase database dynamically on initialization
async function initSupabasePOS() {
    if (typeof supabase === 'undefined') {
        console.warn('Supabase client not detected. Running POS with local mock catalog.');
        renderCart();
        return;
    }

    try {
        const { data: dbProducts, error } = await supabase.from('products').select('*');
        if (!error && dbProducts && dbProducts.length > 0) {
            const dynamicCatalog = {};
            dbProducts.forEach(p => {
                // Map database fields to the UI product structure
                const key = p.sku || p.name.toLowerCase().replace(/\s+/g, '_');
                dynamicCatalog[key] = {
                    name: p.name,
                    unit: p.unit || 'Cylinder',
                    price: Number(p.price) || 0,
                    returnable: p.returnable !== undefined ? p.returnable : true,
                    discountable: p.discountable !== undefined ? p.discountable : true,
                    description: p.description || 'Database inventory item.'
                };
            });
            productCatalog = dynamicCatalog;
        }

        // Fetch dynamic franchisee accounts from Supabase if table exists
        const { data: dbAccounts, error: accError } = await supabase.from('franchisees').select('id, name, package_tier');
        if (!accError && dbAccounts && dbAccounts.length > 0) {
            franchiseeAccounts = dbAccounts.map(acc => ({
                id: acc.id,
                name: acc.name,
                package: (acc.package_tier || 'Standard') + ' package'
            }));
        }
    } catch (err) {
        console.log('Using fallback inventory catalog:', err.message);
    } finally {
        renderCart();
    }
}

function money(value){return '₱'+value.toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2})}
function cartIsFranchisee(){return $('#cartCustomer').value==='franchisee'}

function calculateCartLine(line){
    const item=productCatalog[line.id];
    if(!item) return {qty:0,empty:0,exchange:0,newQty:0,total:0,note:'Item unavailable'};
    const qty=Math.max(0,Number(line.qty)||0),empty=Math.max(0,Number(line.empty)||0),discount=cartIsFranchisee()&&item.discountable?3:0;
    if(!item.returnable)return{qty,empty:0,exchange:0,newQty:qty,total:qty*Math.max(0,item.price-discount),note:`${qty} new item${qty===1?'':'s'}`};
    const exchange=Math.min(qty,empty),newQty=Math.max(0,qty-exchange),content=Math.max(0,item.price-discount),container=line.id==='refill'?25:0,total=exchange*content+newQty*(content+container);
    return{qty,empty,exchange,newQty,total,note:empty>qty?'Review: returns exceed items issued.':newQty?`${exchange} exchange · ${newQty} new item${newQty===1?'':'s'}`:`${exchange} exchange item${exchange===1?'':'s'}`
}

function updateChoiceStates(){const customer=$('#cartCustomer').value,payment=$('#cartPayment').value,account=$('#cartAccount').value;$$('[data-cart-customer]').forEach(button=>button.classList.toggle('active',button.dataset.cartCustomer===customer));$$('[data-cart-payment]').forEach(button=>button.classList.toggle('active',button.dataset.cartPayment===payment));$$('[data-cart-account]').forEach(button=>button.classList.toggle('active',button.dataset.cartAccount===account));}

function renderAccountSuggestions(){const input=$('#accountSearch'),list=$('#accountSuggestions'),query=input.value.trim().toLowerCase();if(!cartIsFranchisee()||!query){list.classList.add('hidden');list.innerHTML='';return}const matches=franchiseeAccounts.filter(account=>`${account.name} ${account.package}`.toLowerCase().includes(query));list.innerHTML=matches.length?matches.map(account=>`<button type="button" data-account-result="${account.id}"><b>${account.name}</b><small>${account.package}</small></button>`).join(''):'<p>No matching franchisee account.</p>';list.classList.remove('hidden');$$('[data-account-result]').forEach(button=>button.addEventListener('click',()=>{const account=franchiseeAccounts.find(entry=>entry.id===button.dataset.accountResult);$('#cartAccount').value=account.id;input.value=account.name;list.classList.add('hidden');renderCart()}))}

function stepLine(index,field,amount){const line=cart[index],current=Math.max(0,Number(line[field])||0);line[field]=Math.max(0,current+amount);renderCart()}

function renderCart(){
    const franchisee=cartIsFranchisee();
    $('#accountField').classList.toggle('hidden',!franchisee);
    $('#cartProof').classList.toggle('hidden',$('#cartPayment').value==='Cash');
    updateChoiceStates();
    
    const choices=Object.entries(productCatalog).map(([id,item])=>`<button type="button" data-add-item="${id}"><b>${item.name}</b><small>${item.unit} · ${item.returnable?'exchange-aware':'standard sale'}</small></button>`).join('');
    $('#itemChoices').innerHTML=choices;
    
    const totals=cart.map(calculateCartLine),total=totals.reduce((sum,line)=>sum+line.total,0);
    
    $('#cartLines').innerHTML=cart.length?cart.map((line,index)=>{
        const item=productCatalog[line.id];
        if(!item) return '';
        const calculation=totals[index],stepper=(field,value,label)=>`<label>${label}<span class="quantity-stepper"><button type="button" data-step="${index}" data-field="${field}" data-change="-1">−</button><input readonly value="${value||0}"><button type="button" data-step="${index}" data-field="${field}" data-change="1">＋</button></span></label>`;
        return `<article class="cart-line ${calculation.empty>calculation.qty?'needs-review':''}"><div class="cart-item"><b>${item.name}</b><small>${item.unit} · ${item.description}</small></div>${stepper('qty',line.qty,'Filled')}${item.returnable?stepper('empty',line.empty,'Empty return'):'<span class="cart-no-return">No return required</span>'}<div class="cart-line-total"><b>${money(calculation.total)}</b><small>${calculation.note}</small></div><button type="button" class="remove-line" data-remove="${index}" aria-label="Remove ${item.name}">×</button></article>`
    }).join(''):'<div class="cart-empty"><b>Your cart is empty.</b><span>Choose an item below to begin a sale.</span></div>';
    
    $('#cartReceiptLines').innerHTML=cart.length?cart.map((line,index)=>{
        const item=productCatalog[line.id];
        return item ? `<p><span>${totals[index].qty||0} × ${item.name}</span><b>${money(totals[index].total)}</b></p>` : '';
    }).join(''):'<p><span>No items added</span><b>—</b></p>';
    
    const hasReturnable=cart.some(line=>productCatalog[line.id]?.returnable),hasNew=totals.some(line=>line.newQty>0),hasExchange=totals.some(line=>line.exchange>0);
    $('#cartTitle').textContent=cart.length?(hasExchange&&hasNew?'Mixed transaction':hasExchange?'Exchange transaction':'New sale'):'New sale';
    $('#cartTotal').textContent=money(total);
    $('#cartNote').textContent=cart.length?(totals.some(line=>line.empty>line.qty)?'Review required: a returned quantity exceeds the filled quantity.':`${cart.length} item line${cart.length===1?'':'s'} · ${hasReturnable?'Cylinder/crate custody will be recorded per line.':'Standard item sale.'}`):'Add items to begin the transaction.';
    
    $$('[data-add-item]').forEach(button=>button.addEventListener('click',()=>{cart.push({id:button.dataset.addItem,qty:0,empty:0});renderCart()}));
    $$('[data-step]').forEach(button=>button.addEventListener('click',()=>stepLine(Number(button.dataset.step),button.dataset.field,Number(button.dataset.change))));
    $$('[data-remove]').forEach(button=>button.addEventListener('click',()=>{cart.splice(Number(button.dataset.remove),1);renderCart()}));
}

$$('[data-cart-customer]').forEach(button=>button.addEventListener('click',()=>{$('#cartCustomer').value=button.dataset.cartCustomer;if(!cartIsFranchisee())$('#accountSearch').value='';renderCart();renderAccountSuggestions()}));
$$('[data-cart-payment]').forEach(button=>button.addEventListener('click',()=>{$('#cartPayment').value=button.dataset.cartPayment;renderCart()}));
$('#accountSearch').addEventListener('input',renderAccountSuggestions);
$('#accountSearch').addEventListener('focus',renderAccountSuggestions);
$('#clearCart').addEventListener('click',()=>{cart=[];renderCart()});

// Complete Sale and Sync to Supabase Database
$('#completeCart').addEventListener('click',async()=>{
    const totals=cart.map(calculateCartLine);
    if(!cart.length){toast('Add at least one item before completing the sale.');return}
    if(totals.some(line=>line.empty>line.qty)){toast('Review the cart: a return cannot exceed its filled quantity.');return}
    if($('#cartPayment').value!=='Cash'&&!$('#cartProof input').files.length){toast('Attach payment proof before completing this sale.');return}

    const customerType = $('#cartCustomer').value;
    const accountId = customerType === 'franchisee' ? $('#cartAccount').value : null;
    const paymentMethod = $('#cartPayment').value;
    const totalAmount = totals.reduce((sum, line) => sum + line.total, 0);

    const completeBtn = $('#completeCart');
    completeBtn.disabled = true;
    completeBtn.textContent = 'Syncing to Supabase...';

    try {
        if (typeof supabase !== 'undefined') {
            // Insert transaction into Supabase table 'sales_transactions'
            const { error: saleError } = await supabase
                .from('sales_transactions')
                .insert([{
                    customer_type: customerType,
                    account_id: accountId,
                    payment_method: paymentMethod,
                    total_amount: totalAmount,
                    status: 'completed',
                    created_at: new Date()
                }]);

            if (saleError) throw saleError;
        }

        toast('Sale completed and synced to Supabase successfully!');
        cart=[];
        renderCart();
    } catch (err) {
        console.error('Supabase transaction error:', err.message);
        toast('Completed locally, but failed to sync to database: ' + err.message);
    } finally {
        completeBtn.disabled = false;
        completeBtn.textContent = 'Complete sale & print';
    }
});

$('#saveCart').addEventListener('click',()=>toast('Cart saved as a pending transaction.'));

// Run initialization
initSupabasePOS();
